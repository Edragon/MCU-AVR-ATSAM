Filelist:
SAM_D10_Xplained_Mini_layer_plots_release_rev2.pdf : PCB Layer Plots
SAM_D10_Xplained_Mini_design_documentation_release_rev2.pdf : Design Documentation
BOM\Bill of Materials Print- SAM_D10_Xplained_Mini_release_rev2.xls : BOM, fitted components
ExportSTEP\SAM_D10_Xplained_Mini_release_rev2.step : 3D Model of PCBA
NC Drill\SAM_D10_Xplained_Mini_release_rev2.drl : Drill files, gerber
NC Drill\SAM_D10_Xplained_Mini_release_rev2.drr : Drill files, report
ODB\SAM_D10_Xplained_Mini_release_rev2.zip : ODB++ Files
Pick Place\Pick Place for SAM_D10_Xplained_Mini_release_rev2.txt : Pick and Place file, component placement
Test Points\Assembly Testpoint Report for SAM_D10_Xplained_Mini_release_rev2.txt : Assembly Testpoint report, txt
NC Drill\SAM_D10_Xplained_Mini_RoundHoles_release_rev2.txt : Drill files, ASCII RH
NC Drill\SAM_D10_Xplained_Mini_SlotHoles_release_rev2.txt : Drill files, ASCII SH
Gerber\SAM_D10_Xplained_Mini_release_rev2.GBO : Gerber files for Bottom Overlay
Gerber\SAM_D10_Xplained_Mini_release_rev2.GBL : Gerber files for Bottom Layer
Gerber\SAM_D10_Xplained_Mini_release_rev2.GBS : Gerber files for Bottom Solder
Gerber\SAM_D10_Xplained_Mini_release_rev2.GM1 : Gerber files for Mechanical 1
Gerber\SAM_D10_Xplained_Mini_release_rev2.GTL : Gerber files for Top Layer
Gerber\SAM_D10_Xplained_Mini_release_rev2.GTO : Gerber files for Top Overlay
Gerber\SAM_D10_Xplained_Mini_release_rev2.GTP : Gerber files for Top Paste
Gerber\SAM_D10_Xplained_Mini_release_rev2.GTS : Gerber files for Top Solder
Gerber\SAM_D10_Xplained_Mini_release_rev2.GP1 : Gerber files for Power Plane
Gerber\SAM_D10_Xplained_Mini_release_rev2.G1 : Gerber files for GND
